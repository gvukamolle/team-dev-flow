---
name: finish-ticket
description: "Report completed chat or tracked work with actual verification and perform authorized Git handoff; preserve applicable merge and release gates."
---

# Finish work

Use [adaptive execution](../../references/governance/adaptive-flow.md). Confirm the
accepted result, relevant checks, a scoped final diff and any required current-SHA
independent review or eligible human approvals. Use [bounded review](../../references/review/bounded-review.md); unchanged-tree mappings replace repeated final LLM attestations. Do not require a tracker, formal contract, JSON artifact or
unrequested deployment to finish ordinary chat work.

Report what changed, how it was checked, and material limitations. Record the full
SHA for committed delivery. For a selected formal-contract workflow, use the
existing v1/v2 handoff schema and check material source drift. Otherwise a concise
human report is sufficient. List follow-ups without creating tickets unless asked.

## Authorized delivery

Check remote, branch, diff ownership and exact candidate SHA. Push, PR/MR creation,
merge, release, deployment and tracker writes require applicable user authority and
repository permission. No branch prefix grants standing push authority. Reuse
explicit authority already given for this workflow; never bypass protected branches.
The GitHub adapter in this package provides previews only. Tracker closure requires
actual requested acceptance evidence and the selected adapter's supported capability.

A same-SHA push preserves code verification/review evidence. Recheck remote SHA,
approvals, CI, base and mergeability before merge; changed code, scope or relevant
base/environment requires affected checks within the same two-pass budget. Clean
same-tree merges reuse existing reports through `scripts/review_equivalence.py`.
Source merge, package/catalog publication, installation, restart/new session and
live smoke are separate facts. Complete requested surfaces and required release
checks; report other surfaces only when relevant, without expanding the task.
