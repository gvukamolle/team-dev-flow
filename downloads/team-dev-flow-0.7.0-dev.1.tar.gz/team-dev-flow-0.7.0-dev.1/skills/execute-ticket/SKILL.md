---
name: execute-ticket
description: "Implement a clear chat or tracked scope, run proportional verification, and add independent roles only when requested or required by risk/project gates."
---

# Execute accepted work

Use [adaptive execution](../../references/governance/adaptive-flow.md). Require a
clear result, correct repository/branch, known dirty-work ownership, no unresolved
blocker and user authority for edits. An already satisfied preflight is reused.
A formal Task Contract is required only by explicit user/project policy; validate
its existing schema, source revision and hash when selected.

## Build and verify

- Own the implementation as Builder; delegation is optional for independent work.
  Preserve user/other-agent changes and use the smallest coherent patch.
- Keep a short plan for dependent work or migration. Do not create separate tasks,
  documents or agents for routine steps. For migration, include invariants and rollback.
- Cover changed behavior and relevant negative paths. Run focused checks during work
  and the required project checks on the final candidate. Do not disable checks or
  add fake assertions. Update docs/contracts when behavior requires it.
- Carry user-approved clarifications forward. Pause dependent work on newly
  discovered material scope/risk/ownership changes; do not manufacture a tracker
  update as an implementation permission gate.
- Inspect the diff and `git diff --check`. Record actual commands/results against
  the checked code state; HEAD alone cannot identify dirty changes.

## Conditional independent gates

Use [bounded review](../../references/review/bounded-review.md): existing eligible human reviews count; no automatic Verifier/Reviewer pair and no extra final review. One owner has one full pass plus one delta across tasks and branches.

Use a read-only Verifier only when user/project policy requires independent
verification. Run it on a reviewable final candidate, not after every edit. Never
claim Builder checks were independent. Add a specialist only for a concrete material
security risk that existing qualified review does not cover. Eligible human
approvals may supply required independent review; they are not an extra gate after
an automatic agent review.
Applicable project requirements remain mandatory even for a small change.

Give required roles the accepted chat scope or selected contract, relevant diff,
full SHA, repository rules and existing evidence. Structured verification/review
reports are required only for a selected formal-contract workflow. Reuse valid
checks; changed code invalidates affected evidence. For clean unchanged trees and
scope/base/environment, record mechanical equivalence to the original report rather
than requesting another verdict. Provider approvals still bind to the current MR.

When required gates pass, finish using [finish-ticket](../finish-ticket/SKILL.md).
Do not create a review loop, ledger or JSON handoff for ordinary chat work.
