---
name: team-dev-flow
description: "Use Team Dev Flow to implement chat or tracked work with proportional checks, create specs when requested, review changes and prepare a Git handoff."
---

# Team Dev Flow router

Use [adaptive execution](../../references/governance/adaptive-flow.md): understand
→ implement → verify → report. Chat is a valid source. Tracking, formal contracts,
specifications and independent roles are conditional, not prerequisites for every task.
Preserve user work, repository rules and explicit authority. Carry accepted
clarifications forward. Use [bounded review](../../references/review/bounded-review.md).
Read [requirements](../../REQUIREMENTS.md) when changing the process.

## Routing

- Explicit request for an Initiative/Epic or specification → [specify](../specify/SKILL.md).
- Ready Spec requiring task decomposition → [plan-work](../plan-work/SKILL.md).
- Selected Local Markdown/Obsidian root → [local-task-store](../local-task-store/SKILL.md).
- Start or continue chat, GitHub or local work → [start-work](../start-work/SKILL.md).
- Unknown impact or research request → [discover-and-scope](../discover-and-scope/SKILL.md).
- Understood implementation request → [execute-ticket](../execute-ticket/SKILL.md).
- Independent review → [review-loop](../review-loop/SKILL.md).
- Findings or comments → [address-feedback](../address-feedback/SKILL.md).
- Completion or Git handoff → [finish-ticket](../finish-ticket/SKILL.md).
- Install, update or diagnose → [setup](../setup/SKILL.md).

Load only the route needed. A feature, bugfix or refactor label alone does not request a Spec.
