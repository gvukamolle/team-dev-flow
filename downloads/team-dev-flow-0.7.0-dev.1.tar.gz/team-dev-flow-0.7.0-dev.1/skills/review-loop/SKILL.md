---
name: review-loop
description: "Use existing human review or one bounded agent cycle: full pass plus one delta, concrete security gaps only, and mechanical unchanged-tree reuse."
---

# Bounded review

Follow [bounded review](../../references/review/bounded-review.md).
A review request or formal contract does not require an additional Verifier.

1. Identify existing review and one owner. Reuse actual eligible human review where
   it covers the change under project policy. Pending approvals mean awaiting human
   review. Agent PASS and native auto-approval do not replace required people.
2. If an agent review is needed (no covering human review, an explicit request, or a
   concrete uncovered material security risk), provide accepted scope, relevant diff,
   reviewed baseline/SHA and real Builder/CI check evidence. Read-only Reviewer owns
   one full pass. Include security in that scope rather than adding a second generic audit.
3. Collect evidenced in-scope findings. Fix accepted findings and run affected tests.
   One delta pass checks those fixes and introduced regressions. Preserve dispositions;
   do not restart broad review, reset the budget at a new SHA or recruit another reviewer.
4. After two automatic passes, unresolved consequential defects require an owner
   decision. Never call them PASS because the limit elapsed. New concrete defects
   may be reported, but do not authorize endless automatic cycles.
5. For unchanged clean trees and unchanged scope/base/environment, keep the original
   report and use `scripts/review_equivalence.py`. A merge/push/branch transition
   alone does not require a new LLM verdict. Live provider approvals remain separate.

## Optional legacy structured evidence

Use existing report/ledger schemas only when an explicit project audit requirement
selects them and actual qualifying evidence exists. A formal Task Contract alone is
not such a requirement. Never fill an independent-verification schema with Builder
self-checks or invented contract fields merely to satisfy a format. Ordinary review
uses a concise report. Historical five-pass records remain readable; new automatic
ledger cycles stop at two. See [stop conditions](../../references/review/stop-conditions.md).

No tracker write or follow-up ticket is required unless requested or independently
required by project policy. Findings need location, severity, scope and evidence.
