---
name: start-work
description: "Start or resume work from a clear chat request or an explicitly selected tracker/local record; inspect the repository and add only required gates."
---

# Start or resume work

Use [adaptive execution](../../references/governance/adaptive-flow.md). Default:
understand the result → implement → verify → report.

1. Reuse the accepted goal and context from this session. For new work, read the
   request, repository root/nested `AGENTS.md`, branch/HEAD, dirty-work ownership,
   relevant code and available checks. Read only context needed for the decision.
2. Chat is a valid scope source. Load a TaskStore only when explicitly selected or
   required by project policy; an installed adapter alone does not require tracking.
   For selected tracked work, read its normalized context using the available adapter.
   Do not infer hierarchy, dependencies or ordering from issue identifiers.
3. Resolve real blockers and decision-changing uncertainty. Ask one focused question
   if necessary; continue independent useful work. Do not emit a separate readiness
   ceremony for an already clear request.
4. Keep compact session state: result, scope, repository/branch, authority, risks and
   checks. Build a schema-valid v1/v2 Task Contract only when explicitly required.
   Preserve live-source revision/hash validation for that formal path.
5. On an accepted clarification, update affected state and proceed. Synchronize a
   tracker only when requested/required; publication blocks edits only when project
   policy explicitly requires it. Follow adapter mutation safeguards for any write.
6. Proceed to [execute-ticket](../execute-ticket/SKILL.md) when implementation is
   requested and unblocked. Use research/specification only for an actual missing
   decision or an explicit deliverable. No automatic SDD/decomposition chain.
