---
name: discover-and-scope
description: "Resolve a concrete uncertainty with bounded read-only research; draft tracked/spec artifacts only when requested or required."
---

# Resolve uncertainty

Use [adaptive execution](../../references/governance/adaptive-flow.md). Research is
read-only; a research-only request never authorizes production implementation.

1. State the decision or missing fact that prevents progress. Reuse accepted scope
   and relevant context; do not restart intake or explore unrelated systems.
2. Inspect the owning code, relevant tests and affected interfaces. Expand into
   neighboring services only when evidence shows a dependency. Load tracker context
   only when selected/required. A bounded independent explorer is optional.
3. Return verified facts, affected components, the smallest viable approach and any
   remaining decision. Include alternatives only when there is a real trade-off.
   Match detail to uncertainty; no mandatory Research Brief, hierarchy or decomposition.
4. If implementation was already authorized and the result stays within accepted
   scope, resume [execute-ticket](../execute-ticket/SKILL.md). If a material decision
   changes scope/risk/ownership, ask before dependent work. If the user asked only
   for research, finish with findings and a recommendation.
5. Create a Spec, task draft or decomposition only when explicitly requested or
   required by project policy. Load that focused skill then; any actual TaskStore
   write retains its provider authorization and validation rules.
