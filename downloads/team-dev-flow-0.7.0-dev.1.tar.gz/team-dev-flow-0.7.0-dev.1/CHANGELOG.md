# Changelog

## 0.7.0-dev.1 — Public refresh candidate

- Add a native Claude Code manifest for session-local plugin loading.

- Port adaptive chat-first flow and bounded review from the cached upstream source.
- Add review equivalence and branch-scope regression coverage.
- Include optional contract validation, worktree snapshots and committed-diff scope checks.
- Preserve structured contracts and existing public adapters.
- Remove mandatory contracts and repeated review from public host defaults.
- Keep organization-specific integrations, push authority and approval counts out.


## 0.6.0-dev.2 — 2026-08-25

- Published the first organization-neutral Universal distribution.
- Included provider-neutral contracts and Agentic SDD with five Spec types.
- Included Local Markdown/Obsidian TaskStore with atomic writes and native Bases views.
- Included Kilo Code host packaging and GitHub Issue read plus Issue/PR preview.
- Excluded organization-specific Jira, internal updater/setup, identifiers, URLs,
  credentials, and corporate release policy.
- Licensed the project under Apache-2.0.
