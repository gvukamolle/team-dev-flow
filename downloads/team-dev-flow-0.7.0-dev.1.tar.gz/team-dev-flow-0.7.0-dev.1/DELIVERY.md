# Public delivery

This checkout is a local `0.7.0-dev.1` candidate. Publication is separate.

1. Run Node/Python tests, repository validation and `git diff --check`.
2. Inspect accepted scope and the complete diff, including public-boundary checks.
3. Build the deterministic archive twice and compare its SHA-256. Verify every file
   against the candidate source. An uncommitted candidate is identified by a content
   manifest; do not call HEAD alone the tested candidate.
4. Smoke the extracted host package in a disposable project and verify its inventory.
5. Review current remote/catalog state and obtain applicable publication authority.
6. For a release, repeat source/package identity checks from the exact clean commit,
   publish its immutable reference and digest, then separately test installation and
   a new-session workflow. A stable claim needs an independent real-task pilot.

The landing can be hosted as static files from `site/`. Before deployment, choose
its origin and set an absolute social-image URL. Keep the install label honest about
which canary the marketplace actually supplies. Rollback restores the prior immutable
marketplace pointer and prior static site artifact.
