# Optional local evidence helpers

These helpers are available when the work needs them; they are not mandatory chat intake.

- `python3 scripts/validate_contract.py task-contract.json` validates the selected
  v1/v2 schema and the canonical contract hash. `--print-hash` computes the hash;
  it does not certify that the contract was accepted or that its source is current.
- `python3 scripts/snapshot_hash.py` hashes non-ignored tracked and untracked regular
  files. It rejects symlinks and missing tracked files. Store the resulting evidence
  outside the measured tree to avoid changing the snapshot by writing its report.
- `python3 scripts/check_scope_diff.py --base BASE --allow core --allow scripts`
  checks paths in the committed merge-base-to-HEAD diff. It does not inspect dirty or
  untracked work and is not a substitute for checking the actual candidate contents.

None of these tools grants authority, verifies human acceptance, or issues independent
review. Use the selected source and actual repository policy for those decisions.
