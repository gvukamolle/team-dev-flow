# Pull request / merge request handoff

Lead with changed behavior and its purpose. Include relevant checks/results, risks,
unverified surfaces and original reviewed revision. Include TaskStore/Spec/contract
references only when selected; add rollout and rollback notes when relevant.

Changed code, scope or relevant context invalidates affected evidence. Same-SHA
pushes preserve it; clean identical trees need mechanical context equivalence.
Human approvals and current provider gates must still be checked on the target PR/MR.
Creation, merge, protection changes, release and deploy require applicable authority.
