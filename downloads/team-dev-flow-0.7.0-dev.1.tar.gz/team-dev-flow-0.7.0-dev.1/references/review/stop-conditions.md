# Review stop conditions

Follow [bounded review](bounded-review.md) for all work.

## PASS or reused evidence

- Required scope and behavior are covered by actual review/check evidence.
- No unresolved consequential in-scope P0-P2 defect remains.
- The report names its original reviewed SHA. A new clean SHA can reuse it through
  verified identical tree and unchanged scope/base/environment; keep that mapping.
- Required human approvals are actual eligible people on the current MR/commit;
  pending or native Auto approved is not proof of human review.
- Findings have evidence-backed dispositions and required checks pass.

A tracker, JSON report or separate Verifier is not a universal prerequisite.

## REQUEST_CHANGES

Use on the first automatic pass for a consequential evidenced in-scope defect or
failed required check. Fix and verify it, then check only the delta.

## ESCALATE

Stop automation after the second pass if a consequential defect remains, or when an
unresolved owner decision/authority is needed. Do not start a third reviewer, rename
the task to reset the budget, or declare success with known blockers. Optional polish
and unrelated debt do not block. A repeated evidence-free disagreement does not
justify another automatic pass.

Legacy ledger readers still accept historical five-pass records. New writes enforce
two automatic passes even when a new finding or new evidence appears. Reopening an
automatic cycle requires an explicit owner decision; never erase previous history.
