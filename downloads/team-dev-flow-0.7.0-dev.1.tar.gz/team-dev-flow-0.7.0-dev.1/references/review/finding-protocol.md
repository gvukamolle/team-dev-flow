# Finding protocol

Every finding states:

- unique finding ID;
- ticket and exact full 40- or 64-character reviewed SHA; abbreviated SHAs are invalid evidence;
- severity and scope class;
- narrow code location;
- observable claim;
- evidence or reproduction path;
- expected behavior from the contract/rule;
- smallest safe corrective action;
- whether the current change introduced the issue.

Bad finding:

> This code could be cleaner and might not scale.

Good finding:

> `REV-004`, P2, in scope, reviewed SHA `abc…`: the new retry loop in `worker.py:91` retries non-idempotent POST after a read timeout, so one request can create two records. AC-03 requires single creation. Restrict retries to the idempotency-key path or persist the request key before retrying.

[Bounded review](bounded-review.md) controls when review and structured evidence are needed.
Ordinary findings need a location, severity, accepted scope and reproduction evidence.
Rejection needs evidence. Defer work only when it does not prevent accepted completion;
create a follow-up record only when requested or required by project policy.

For an explicitly selected audit workflow, `scripts/review_ledger.py add-pass --packet`
computes its result from actual independent verification and finding dispositions.
Use v2 scope/source-revision fields for provider-neutral work. Legacy v1 remains readable.
Never fill an independent report with Builder self-checks or fabricated evidence.
`check-current` verifies code, contract and source currency. Repeated unsupported
blocking claims escalate; new automatic writes stop after two passes. Historical
five-pass records remain readable. A changed SHA never resets that budget.
