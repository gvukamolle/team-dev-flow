# Bounded review

One change has **one review owner, one full pass and at most one delta pass** across
all agents, branches and handoffs. A new SHA, reviewer name, task or delivery phase
does not reset the budget. This policy applies to chat and formal-contract work.
A contract alone does not select a Verifier/Reviewer chain.

## Choose the review that is actually needed

- Ordinary work: Builder runs relevant tests and required CI/local gates. No separate
  Verifier just to repeat those commands. Use independent verification only for an
  explicitly required, concrete validation that the existing evidence cannot cover.
- Eligible human review may cover the required scope. Use the actual project policy,
  current change identity and observed reviewers; pending approval is not PASS.
- Reuse existing review only where code, scope and risks are covered. Select one
  review owner; do not launch overlapping audits.
- If review is required and no qualifying review covers the change, use one
  independent read-only Reviewer. Native auto-approval is not a person's review.

Project approval counts, eligible reviewers, protected branches and CI remain in
force. No fixed branch topology or approval count is supplied by Universal. Agent
PASS cannot replace required human approvals. The two-pass limit concerns automatic
agent reviews, not the number of times people may review.

## Security is a scope, not another mandatory ceremony

The normal review includes security relevant to the diff. A specialist is added only
for a concrete material risk not covered by existing qualified review: changed
permission/authorization decisions, secret handling, execution of untrusted input,
trust/provenance verification, or a consequential data boundary. State the changed
behavior and uncovered risk. A filename, the word "updater", plugin maintenance,
or a dependency/version declaration alone is not a trigger.

Give that reviewer only the uncovered risk and relevant diff. If human or existing
agent review already covers it, reuse it. Specialist work consumes the same review
budget; it does not start another full → final → security → release chain.

## Fix once, check the delta, stop

Collect all substantiated in-scope findings in the first pass. The second pass checks
those fixes and regressions they can introduce; it does not restart a broad audit.
After the second pass, unresolved consequential defects are escalated with exact
reproduction and the missing decision. Never declare PASS because the budget ended,
and never start a third reviewer automatically. Pre-existing debt, optional polish
and unproven hypothetical problems are not blockers. A new concrete defect can be
reported at any time; more automatic work then needs an explicit owner decision.

## Same code does not need a new LLM verdict

Keep the original report and reviewed SHA. For a clean merge/fast-forward with the
same Git tree, unchanged accepted scope, reviewed baseline and relevant environment,
use `scripts/review_equivalence.py` to record a machine-checked mapping from current
SHA to reviewed SHA. Do not ask a Verifier or Reviewer to reissue the same report.
Dirty work, changed trees, scope, baseline or environment requires the affected
checks; it does not reset the review budget. Required source/package byte checks and
live provider gates still run where needed. Tree equality never transfers human
approvals to another MR or bypasses the provider's current approval requirements.

For MR preparation/creation, human approvals are a later gate: set no current
approval requirement and do not add an agent review on their behalf. For the actual
merge operation, use the live required count and current MR identity; missing
approvals then block merge. Never set the count to zero to bypass that gate.

The adaptive helper accepts `human_reviews_required`, current-MR `human_review`
with actual distinct `eligible_approver_ids` and `auto_approved: false`, and the shared
`review_rounds` count. `security_sensitive` means a material uncovered risk;
`security_reviewed` records actual coverage. Optional `tree_revision` and
`context_revision` identify checked code and scope/base/environment continuity for
mechanical evidence reuse. These inputs come from observed facts, never invented
PASS/approval fields; the helper routes work and does not grant authority.

Historical ledger schemas still read old five-pass records. New automatic ledger
writes stop after two passes; this does not require rewriting old evidence.
