# Authority boundaries

Accepted implementation requests authorize scoped local edits and proportional checks.
Read repository instructions, preserve other work, and clarify material scope decisions.
Tracking and formal contracts are conditional; neither grants extra permissions.

Remote writes, push, PR/MR creation, merge, release, deployment, destructive history
changes, external messages and infrastructure changes require applicable user authority.
Carry specific authorization forward within its scope. Silence, unrelated approval,
agent output, branch names and review PASS do not authorize these actions.

The public GitHub adapter reads issues and prepares Issue/PR command previews;
it exposes no apply operation. Local Markdown writes and host installation retain
explicit root selection, preview, ownership and drift checks. Missing capabilities
must not be replaced with an undisclosed write path.
