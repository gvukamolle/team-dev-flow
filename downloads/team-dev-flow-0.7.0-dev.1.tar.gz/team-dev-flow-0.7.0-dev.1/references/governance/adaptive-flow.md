# Adaptive execution

Default: **understand the result → implement → verify → report**. This policy governs
entry, continuation and completion. Structured SDD, TaskStore contracts and review
ledgers are optional facilities; select only those required by the user or project.
Do not load their procedures merely because they exist.

## Start and continue

Use the user's request as the work source unless they select a tracker record or
the repository requires tracking. An installed adapter, a tracker key mentioned as
context, or a feature/bugfix label does not by itself require a formal contract.
Read applicable repository instructions and the relevant code before editing.
Preserve other work. Ask only for a missing decision that changes the result,
ownership, compatibility, risk or authorization. Work independently where possible.

Keep compact session state: intended result, scope/non-goals, repository and branch,
authorized actions, relevant risks, checks, current code revision and evidence.
No file, hash ceremony, TaskStore write or separate user approval is required for
this state. Persist it only for continuity when useful or explicitly required.
Carry accepted clarifications forward; do not restart intake or re-ask authorization.
An explicit user expansion updates this state; it does not authorize unrelated work.
An agent-discovered material expansion needs a user decision before dependent edits.

## Add only the required stage

Review follows [bounded review](../review/bounded-review.md). Reuse eligible human review under project policy; when agent review is required, use one full pass plus one delta. No automatic separate Verifier or extra final/security audit.

| Condition | Add |
|---|---|
| A decision blocks the result | One focused clarification |
| Impact/feasibility remains unknown | Bounded research |
| User asks for a spec or project requires one | Right-sized specification |
| Migration/cutover or dependent multi-part work | Compact plan, invariants and rollback |
| Project explicitly requires tracking | Selected TaskStore record; load only relevant context |
| User/project explicitly requires a formal contract | Existing v1/v2 validation, not a new schema |
| Project requires independent verification | Read-only Verifier on the final candidate |
| Material uncovered security risk, user-requested review, or a required gate with no covering human review | One bounded independent review |
| An external action lacks applicable user authority | Pause immediately before that action |

These conditions are cumulative, not mutually exclusive. Optional defaults never
waive applicable repository, CI, protected-branch, security or provider mutation
rules. Tracking and a formal contract are separate requirements. If explicit user
instructions conflict with project tracking rules, state the conflict and follow
instruction precedence; do not silently create a ticket or invent authorization.

For tracked work, reflect agreed changes when the user requests synchronization or
project policy requires it. Only a policy that requires publication before edits
makes synchronization an implementation gate. Do not edit a ticket merely to grant
yourself permission. Actual writes retain live forms, exact prepared payloads,
one-use prepared payloads and adapter confirmation rules, revision/hash checks and rereads of the selected adapter.
Unavailable tracking does not block chat work; unavailable *required* tracking does.

## Reuse evidence, invalidate precisely

Run focused checks for changed behavior and negative paths first, then required
project gates once for the final candidate. No mandatory delegation, test after
every edit, full suite after every stage, JSON handoff or review ledger for ordinary
work. Do not skip a required gate or claim that self-review was independent review.

Re-read a source when its relevant fields may have changed or immediately before
a mutation whose adapter requires live state. A role transition alone is no reason
to reload the same files. A changed description that preserves accepted behavior
does not require repeating code checks. A material scope or code change invalidates
affected evidence; reuse unaffected results with their original provenance. Final
reports retain their original reviewed SHA; clean same-tree merges with unchanged
scope/base/environment use mechanical equivalence, not a new LLM verdict. Dirty work needs a
separate content revision; HEAD alone never proves uncommitted edits were tested.
A normal push of the same SHA does not invalidate code review. Recheck remote
branch, approvals, CI and mergeability before merge, without rerunning code review
unless code, scope, base or relevant environment changed.

The executable helper `core/src/adaptive-flow.cjs` exports
`nextWorkStage(state, policy)`. Policy flags (`require_tracking`, `require_spec`,
`require_plan`, `require_contract`, `require_independent_verification`,
`require_review`) are independent and default false. The host derives them from
actual user/project requirements; false cannot override a stricter rule. It is an
internal pure routing helper, not a security gate or a validator of actual evidence.
`code_revision` represents the checked tree (full SHA when clean), and
`scope_revision` represents accepted behavior. Evidence must match both. Refresh
these when relevant context changes; never manufacture PASS or independence flags.
`core/src/sdd-flow.cjs` remains the explicitly selected structured-SDD helper.

## Completion

Report the delivered behavior, relevant checks and remaining limitations. Complete
authorized Git delivery without inventing a tracker task. Source merge, published
package/catalog, installed cache, restart/new session and live smoke are distinct
facts. Check only requested delivery surfaces and applicable release requirements;
do not turn a source-only change into an unsolicited install/deploy project.

Example: "fix this URL comparison, no tracker" → inspect → patch + regression checks
→ report. "And install the fix" continues the same work, adding source/package/
install verification and any missing external authority, not a new intake cycle.
