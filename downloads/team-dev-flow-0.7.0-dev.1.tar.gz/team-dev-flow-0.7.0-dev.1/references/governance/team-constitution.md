# Team constitution

1. Agree on scope before changing it. Chat is a valid source; tracking is conditional.
2. Keep unrelated work out and preserve existing edits.
3. People retain decisions about requirements, risk, approval and release.
4. Prefer evidence over confidence; identify checked code, context and limitations.
5. Current relevant state outranks stale context; report unavailable source freshness.
6. Builder self-checks are not independent review. Add independent roles only when required.
7. Follow project branch, CI and approval rules; Universal imposes no corporate topology.
8. Keep credentials and raw sensitive data out of artifacts and logs.
9. Automation cannot grant itself authority for external actions.
10. Use deterministic checks where mechanics can enforce the rule.
11. Improve from consequential observed failures, not speculative process expansion.
