# Team Dev Flow workspace rule

Load the `team-dev-flow` skill when Team Dev Flow is requested.
Follow repository `AGENTS.md`. Default to accepted chat → implementation → checks → report.
Tracking and formal contracts are required only by explicit user/project policy.
Preserve other work. Bind evidence to checked code and scope; a same-SHA push does
not invalidate it. Reuse identical clean trees only with verified context equivalence.
Remote writes and installation retain applicable user authorization and adapter checks.
