# Universal architecture

Skills route accepted chat or tracked work. `adaptive-flow.cjs` is a pure routing
helper with independent policy flags for tracking, specs, plans, contracts,
verification and review. Hosts supply observed state; the helper grants no authority.
`core/src/sdd-flow.cjs` retains the explicitly selected structured path.

Provider contracts and flow profiles preserve read/preview/write distinctions.
Local Markdown owns only its selected root. GitHub exposes bounded issue reads and
command previews. Host packaging copies an inventoried plugin into a selected project.

Review ledgers are optional audit facilities. `review_equivalence.py` checks clean
identical Git trees and supplied scope/base/environment context; it does not issue
review verdicts or transfer human approvals. New automatic ledger writes stop at two.

The standalone site and marketing assets have no dependency on the plugin runtime.
They are deliberately excluded from its explicit release inventory.

Claude Code loads the same skill tree via `.claude-plugin/plugin.json` and its
session-local `--plugin-dir` option. The manifest introduces no hooks or MCP writes.
