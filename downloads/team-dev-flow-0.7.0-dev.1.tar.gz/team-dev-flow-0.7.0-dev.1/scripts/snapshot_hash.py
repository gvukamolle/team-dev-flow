#!/usr/bin/env python3
"""Hash every non-ignored tracked or untracked file in the current Git worktree."""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def git_files() -> list[Path]:
    process = subprocess.run(
        ["git", "ls-files", "-co", "--exclude-standard", "-z"],
        cwd=ROOT,
        check=True,
        capture_output=True,
    )
    names = [name for name in process.stdout.split(b"\0") if name]
    return [ROOT / name.decode("utf-8") for name in sorted(names)]


def snapshot(files: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in files:
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"snapshot input must be a regular file: {path.relative_to(ROOT)}")
        relative = path.relative_to(ROOT).as_posix().encode("utf-8")
        content_digest = hashlib.sha256(path.read_bytes()).hexdigest().encode("ascii")
        digest.update(relative + b"\0" + content_digest + b"\n")
    return digest.hexdigest()


def main() -> int:
    files = git_files()
    print(json.dumps({
        "algorithm": "sha256(path + NUL + sha256(content) + LF)",
        "file_count": len(files),
        "snapshot_sha256": snapshot(files),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
