#!/usr/bin/env python3
"""Validate required Task Contract fields and compute its canonical contract hash."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

try:
    from jsonschema import Draft202012Validator
except ModuleNotFoundError as exc:  # Fail closed instead of silently doing partial validation.
    raise SystemExit(
        "jsonschema is required for Task Contract validation; install requirements.txt"
    ) from exc

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATHS = {
    "team-dev-flow/task-contract/v1": ROOT / "contracts" / "task-contract.schema.json",
    "team-dev-flow/task-contract/v2": ROOT / "contracts" / "task-contract-v2.schema.json",
}
SCHEMA_VALIDATORS = {
    version: Draft202012Validator(json.loads(path.read_text(encoding="utf-8")))
    for version, path in SCHEMA_PATHS.items()
}


def canonical_payload(contract: dict) -> bytes:
    payload = dict(contract)
    payload.pop("contract_hash", None)
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def contract_hash(contract: dict) -> str:
    return hashlib.sha256(canonical_payload(contract)).hexdigest()


def validate(contract: dict) -> list[str]:
    errors: list[str] = []
    version = contract.get("schema_version")
    validator = SCHEMA_VALIDATORS.get(version)
    if validator is None:
        return [f"unsupported schema_version: {version!r}"]
    for schema_error in sorted(validator.iter_errors(contract), key=lambda item: list(item.path)):
        location = ".".join(str(part) for part in schema_error.absolute_path) or "$"
        errors.append(f"schema {location}: {schema_error.message}")
    expected = contract_hash(contract)
    if contract.get("contract_hash") != expected:
        errors.append(f"contract_hash mismatch; expected {expected}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("contract", type=Path)
    parser.add_argument("--print-hash", action="store_true")
    args = parser.parse_args()
    contract = json.loads(args.contract.read_text(encoding="utf-8"))
    if args.print_hash:
        print(contract_hash(contract))
        return 0
    errors = validate(contract)
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("Task Contract: valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
