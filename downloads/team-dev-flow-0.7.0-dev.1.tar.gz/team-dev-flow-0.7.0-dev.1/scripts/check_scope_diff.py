#!/usr/bin/env python3
"""Report changed paths outside explicit allowed prefixes."""

from __future__ import annotations

import argparse
import subprocess


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--allow", action="append", required=True)
    args = parser.parse_args()
    output = subprocess.check_output(
        ["git", "diff", "--name-only", f"{args.base}...HEAD"], text=True
    )
    paths = [line for line in output.splitlines() if line]
    unexpected = [
        item for item in paths
        if not any(item == prefix.rstrip("/") or item.startswith(prefix.rstrip("/") + "/") for prefix in args.allow)
    ]
    if unexpected:
        print("Changed paths outside the declared scope:")
        for item in unexpected:
            print(f"- {item}")
        return 1
    print("Diff paths: within declared scope")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

