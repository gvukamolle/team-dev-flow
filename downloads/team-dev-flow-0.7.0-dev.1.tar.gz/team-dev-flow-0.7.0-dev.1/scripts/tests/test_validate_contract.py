import unittest

from scripts.validate_contract import contract_hash, validate


def sample_contract():
    value = {
        "schema_version": "team-dev-flow/task-contract/v1",
        "ticket": "FLOW-350",
        "jira_revision": {"updated": "2026-08-13", "content_hash": "a" * 64},
        "goal": "Synthetic goal",
        "in_scope": ["One behavior"],
        "out_of_scope": [],
        "acceptance_criteria": [{"id": "AC-01", "text": "Works", "verification": "Test"}],
        "repositories": [{"name": "repo", "path": "/tmp/repo", "ownership": "primary"}],
        "dependencies": [],
        "constraints": [],
        "risk": {"level": "normal", "reasons": []},
        "required_validation": ["unit test"],
        "approval_boundaries": [],
        "open_questions": [],
        "contract_hash": "",
    }
    value["contract_hash"] = contract_hash(value)
    return value


class ValidateContractTests(unittest.TestCase):
    def test_valid_contract_hash(self):
        self.assertEqual(validate(sample_contract()), [])

    def test_detects_contract_drift(self):
        value = sample_contract()
        value["goal"] = "Changed"
        self.assertTrue(
            any("contract_hash mismatch" in error for error in validate(value))
        )

    def test_rejects_malformed_nested_acceptance_criterion_even_with_valid_hash(self):
        value = sample_contract()
        value["acceptance_criteria"] = [{"id": "bad", "text": 1}]
        value["contract_hash"] = contract_hash(value)
        errors = validate(value)
        self.assertTrue(any("schema acceptance_criteria.0" in error for error in errors), errors)

    def test_provider_neutral_v2_contract_is_valid(self):
        value = {
            "schema_version": "team-dev-flow/task-contract/v2",
            "scope": {
                "ref": "local_markdown:team-dev-flow:TDF-M0",
                "provider": "local_markdown",
                "native_id": "TDF-M0",
                "kind": "task",
            },
            "source_revision": {"updated": "2026-08-25", "content_hash": "a" * 64},
            "spec_ref": "local_markdown:team-dev-flow:universal-flow",
            "goal": "Add provider-neutral contracts",
            "business_outcome": "One flow works across task stores",
            "in_scope": ["contracts"],
            "out_of_scope": ["provider writes"],
            "acceptance_criteria": [{"id": "AC-01", "text": "v2 validates", "verification": "unit test"}],
            "repositories": [{"name": "team-dev-flow", "path": ".", "ownership": "primary"}],
            "dependencies": [],
            "constraints": ["preserve v1"],
            "risk": {"level": "normal", "reasons": []},
            "required_validation": ["python tests"],
            "approval_boundaries": ["no push"],
            "open_questions": [],
            "contract_hash": "0" * 64,
        }
        value["contract_hash"] = contract_hash(value)
        self.assertEqual(validate(value), [])

    def test_unknown_contract_version_fails_closed(self):
        value = sample_contract()
        value["schema_version"] = "team-dev-flow/task-contract/v999"
        self.assertIn("unsupported schema_version", validate(value)[0])


if __name__ == "__main__":
    unittest.main()
