import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from scripts import snapshot_hash

ROOT = Path(__file__).resolve().parents[2]


class PortableEvidenceTests(unittest.TestCase):
    def test_snapshot_detects_dirty_and_untracked_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            subprocess.run(['git', 'init', '-q', str(root)], check=True)
            tracked = root / 'tracked.txt'
            tracked.write_text('before')
            subprocess.run(['git', '-C', str(root), 'add', '.'], check=True)
            with patch.object(snapshot_hash, 'ROOT', root):
                first = snapshot_hash.snapshot(snapshot_hash.git_files())
                tracked.write_text('after')
                second = snapshot_hash.snapshot(snapshot_hash.git_files())
                self.assertNotEqual(first, second)
                (root / 'new.txt').write_text('untracked')
                self.assertNotEqual(second, snapshot_hash.snapshot(snapshot_hash.git_files()))
                link = root / 'link'
                link.symlink_to(tracked)
                with self.assertRaises(ValueError):
                    snapshot_hash.snapshot(snapshot_hash.git_files())

    def test_committed_scope_check_rejects_path_prefix_lookalike(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            def git(*args):
                return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()
            git('init', '-q')
            git('-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid',
                'commit', '-q', '--allow-empty', '-m', 'base')
            base = git('rev-parse', 'HEAD')
            (root / 'core').mkdir()
            (root / 'core/file.txt').write_text('inside')
            (root / 'core-other').mkdir()
            (root / 'core-other/file.txt').write_text('outside')
            git('add', '.')
            git('-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid',
                'commit', '-q', '-m', 'fixture')
            import sys
            cmd = [sys.executable, str(ROOT / 'scripts/check_scope_diff.py'), '--base', base, '--allow', 'core']
            rejected = subprocess.run(cmd, cwd=root, capture_output=True, text=True)
            self.assertEqual(rejected.returncode, 1)
            self.assertIn('core-other/file.txt', rejected.stdout)
            accepted = subprocess.run(cmd + ['--allow', 'core-other'], cwd=root, capture_output=True, text=True)
            self.assertEqual(accepted.returncode, 0, accepted.stdout)
