import subprocess
import tempfile
import unittest
from pathlib import Path
from scripts.review_equivalence import equivalence


class ReviewEquivalenceTests(unittest.TestCase):
    def test_real_git_same_tree_reuses_but_dirty_changed_context_or_tree_does_not(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            def git(*args):
                return subprocess.check_output(['git', '-C', tmp, *args], text=True).strip()
            git('init', '-q')
            git('config', 'user.name', 'Test')
            git('config', 'user.email', 'test@example.invalid')
            (root / 'code.txt').write_text('first')
            git('add', 'code.txt'); git('commit', '-qm', 'initial')
            before = git('rev-parse', 'HEAD')
            git('commit', '--allow-empty', '-qm', 'merge metadata only')
            after = git('rev-parse', 'HEAD')
            self.assertTrue(equivalence(root, before, after, 'scope/base/env', 'scope/base/env')['reusable'])
            self.assertFalse(equivalence(root, before, after, 'old', 'new')['reusable'])
            (root / 'code.txt').write_text('changed')
            self.assertFalse(equivalence(root, before, after, 'same', 'same')['reusable'])
            git('add', 'code.txt'); git('commit', '-qm', 'code change')
            changed = git('rev-parse', 'HEAD')
            self.assertFalse(equivalence(root, before, changed, 'same', 'same')['reusable'])
            self.assertFalse(equivalence(root, before, after, 'same', 'same')['reusable'])

    def test_missing_context_and_abbreviated_sha_are_rejected(self):
        with self.assertRaises(ValueError):
            equivalence('.', 'abc', 'def', 'same', 'same')
        with self.assertRaises(ValueError):
            equivalence('.', 'a' * 40, 'b' * 40, '', '')


    def test_git_replacement_does_not_hide_a_real_tree_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            def git(*args):
                return subprocess.check_output(['git', '-C', tmp, *args], text=True).strip()
            git('init', '-q'); git('config', 'user.name', 'Test'); git('config', 'user.email', 'test@example.invalid')
            path = Path(tmp) / 'code.txt'
            path.write_text('before'); git('add', 'code.txt'); git('commit', '-qm', 'before')
            before = git('rev-parse', 'HEAD')
            path.write_text('after'); git('add', 'code.txt'); git('commit', '-qm', 'after')
            after = git('rev-parse', 'HEAD')
            git('replace', before, after)
            # Demonstrate that ordinary Git resolution would give a false match.
            self.assertEqual(git('rev-parse', before + '^{tree}'), git('rev-parse', after + '^{tree}'))
            result = equivalence(tmp, before, after, 'same', 'same')
            self.assertFalse(result['reusable'])
            self.assertIn('Git tree changed', result['reasons'])

    def test_tree_object_is_not_a_reviewed_commit(self):
        with tempfile.TemporaryDirectory() as tmp:
            def git(*args):
                return subprocess.check_output(['git', '-C', tmp, *args], text=True).strip()
            git('init', '-q'); git('config', 'user.name', 'Test'); git('config', 'user.email', 'test@example.invalid')
            git('commit', '--allow-empty', '-qm', 'initial')
            commit = git('rev-parse', 'HEAD'); tree = git('rev-parse', 'HEAD^{tree}')
            with self.assertRaisesRegex(ValueError, 'commit objects'):
                equivalence(tmp, tree, commit, 'same', 'same')
