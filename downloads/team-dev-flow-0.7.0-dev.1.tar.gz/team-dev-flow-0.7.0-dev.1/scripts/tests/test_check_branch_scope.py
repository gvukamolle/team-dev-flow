import unittest

from scripts.check_branch_scope import branch_matches, branch_slug


class BranchScopeTests(unittest.TestCase):
    def test_jira_and_local_references_share_one_branch_rule(self):
        self.assertTrue(branch_matches("jira:example:FLOW-350", "feature/FLOW-350-qwen"))
        self.assertTrue(branch_matches("local_markdown:team-dev-flow:universal-core-m0-m2", "feature/universal-core-m0-m2"))

    def test_task_and_fix_branches_match_the_exact_jira_key(self):
        self.assertTrue(branch_matches("jira:example:FLOW-350", "task/FLOW-350"))
        self.assertTrue(branch_matches("jira:example:FLOW-350", "task/FLOW-350-fix"))
        self.assertTrue(branch_matches("jira:example:FLOW-350", "fix/FLOW-350-login"))
        self.assertFalse(branch_matches("jira:example:FLOW-350", "task/FLOW-3500"))

    def test_url_like_native_identifiers_are_safely_slugged(self):
        self.assertEqual(branch_slug("github:org/repo:#6250"), "6250")

    def test_unrelated_branch_is_rejected(self):
        self.assertFalse(branch_matches("jira:example:FLOW-350", "feature/OTHER-6250-admin"))
        self.assertFalse(branch_matches("jira:example:FLOW-350", "feature/FLOW-3500-lookalike"))


if __name__ == "__main__":
    unittest.main()
