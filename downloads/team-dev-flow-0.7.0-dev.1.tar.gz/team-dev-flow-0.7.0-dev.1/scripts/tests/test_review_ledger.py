import unittest

from scripts.review_ledger import check_current, record_pass


SHA = "a" * 40
CONTRACT = "b" * 64
REVISION = {"updated": "2026-08-13T10:00:00.000+0300", "content_hash": "c" * 64}


def ledger():
    return {"schema_version": "team-dev-flow/review-ledger/v1", "passes": []}


def packet(findings=None, verification_result="PASS"):
    verification = {
        "schema_version": "team-dev-flow/verification-report/v1",
        "ticket": "FLOW-350",
        "contract_hash": CONTRACT,
        "jira_revision": REVISION,
        "verified_sha": SHA,
        "verifier": "independent-verifier-session",
        "independent_from_builder": True,
        "environment": "isolated local checkout",
        "checks": [{
            "name": "unit",
            "command_or_method": "python -m unittest",
            "result": "pass" if verification_result == "PASS" else "fail",
            "evidence": "synthetic result",
        }],
        "unverified": [],
        "result": verification_result,
    }
    return {
        "ticket": "FLOW-350",
        "reviewed_sha": SHA,
        "contract_hash": CONTRACT,
        "jira_revision": REVISION,
        "contract_drift": False,
        "verification_report": verification,
        "findings": findings or [],
    }


def provider_neutral_packet(findings=None):
    source_revision = {"updated": "2026-08-25", "content_hash": "d" * 64}
    scope_ref = "local_markdown:team-dev-flow:universal-core-m0-m2"
    verification = {
        "schema_version": "team-dev-flow/verification-report/v2",
        "scope_ref": scope_ref,
        "contract_hash": CONTRACT,
        "source_revision": source_revision,
        "verified_sha": SHA,
        "verifier": "independent-verifier-session",
        "independent_from_builder": True,
        "environment": "isolated local checkout",
        "checks": [{
            "name": "unit", "command_or_method": "python -m unittest",
            "result": "pass", "evidence": "synthetic result",
        }],
        "unverified": [],
        "result": "PASS",
    }
    return {
        "scope_ref": scope_ref,
        "reviewed_sha": SHA,
        "contract_hash": CONTRACT,
        "source_revision": source_revision,
        "contract_drift": False,
        "verification_report": verification,
        "findings": findings or [],
    }


def disagreement(
    evidence=None,
    finding_id="REV-099",
    severity="P2",
    scope="in_scope",
):
    return {
        "finding_id": finding_id,
        "severity": severity,
        "scope": scope,
        "status": "needs_evidence",
        "resolution": "Evidence dispute remains",
        "disagreement": {
            "claim": "The gate is fail open",
            "evidence": evidence or [],
        },
    }


class ReviewLedgerTests(unittest.TestCase):
    def test_pass_is_computed_from_clean_current_evidence(self):
        data = ledger()
        self.assertEqual(record_pass(data, packet())["result"], "PASS")
        self.assertEqual(check_current(data, SHA, CONTRACT, REVISION["updated"], REVISION["content_hash"]), [])

    def test_provider_neutral_packet_promotes_an_empty_ledger_to_v2(self):
        data = ledger()
        value = provider_neutral_packet()
        self.assertEqual(record_pass(data, value)["result"], "PASS")
        self.assertEqual(data["schema_version"], "team-dev-flow/review-ledger/v2")
        self.assertEqual(data["passes"][0]["scope_ref"], value["scope_ref"])
        self.assertEqual(check_current(data, SHA, CONTRACT, value["source_revision"]["updated"], value["source_revision"]["content_hash"]), [])

    def test_provider_neutral_deferred_finding_accepts_a_follow_up_ref(self):
        finding = {
            "finding_id": "REV-201", "severity": "P2", "scope": "adjacent",
            "status": "deferred", "resolution": "Separate follow-up",
            "follow_up_ref": "github:org/repo:6251",
        }
        self.assertEqual(record_pass(ledger(), provider_neutral_packet([finding]))["result"], "PASS")

    def test_unresolved_findings_cannot_produce_pass(self):
        data = ledger()
        finding = {
            "finding_id": "REV-001", "severity": "P1", "scope": "in_scope",
            "status": "accepted", "resolution": "Will fix later"
        }
        outcome = record_pass(data, packet([finding]))
        self.assertEqual(outcome["result"], "REQUEST_CHANGES")
        self.assertTrue(outcome["reasons"])

    def test_failed_verification_cannot_produce_pass(self):
        self.assertEqual(record_pass(ledger(), packet(verification_result="FAIL"))["result"], "REQUEST_CHANGES")

    def test_abbreviated_sha_cannot_produce_pass(self):
        value = packet()
        value["reviewed_sha"] = "abc1234"
        value["verification_report"]["verified_sha"] = "abc1234"
        with self.assertRaises(ValueError):
            record_pass(ledger(), value)

    def test_truncated_verification_report_is_rejected(self):
        value = packet()
        value["verification_report"] = {"verified_sha": SHA, "result": "PASS"}
        with self.assertRaisesRegex(ValueError, "(?:review packet|verification report) schema"):
            record_pass(ledger(), value)

    def test_self_verification_and_empty_checks_are_rejected(self):
        value = packet()
        value["verification_report"]["independent_from_builder"] = False
        value["verification_report"]["checks"] = []
        with self.assertRaisesRegex(ValueError, "(?:review packet|verification report) schema"):
            record_pass(ledger(), value)

    def test_verification_must_match_ticket_contract_and_jira_revision(self):
        for field, replacement in (
            ("ticket", "ML-351"),
            ("contract_hash", "d" * 64),
            ("jira_revision", {"updated": "later", "content_hash": "e" * 64}),
        ):
            with self.subTest(field=field):
                value = packet()
                value["verification_report"][field] = replacement
                outcome = record_pass(ledger(), value)
                self.assertEqual(outcome["result"], "REQUEST_CHANGES")
                self.assertTrue(any(field.split("_")[0] in reason.lower() for reason in outcome["reasons"]))

    def test_second_identical_evidence_free_disagreement_escalates(self):
        data = ledger()
        first = record_pass(data, packet([disagreement()]))
        second = record_pass(data, packet([disagreement()]))
        self.assertEqual(first["result"], "REQUEST_CHANGES")
        self.assertEqual(second["result"], "ESCALATE")
        self.assertTrue(any("repeated" in reason for reason in second["reasons"]))

    def test_changed_finding_id_does_not_evade_same_claim_escalation(self):
        data = ledger()
        record_pass(data, packet([disagreement(finding_id="REV-099")]))
        second = record_pass(data, packet([disagreement(finding_id="REV-101")]))
        self.assertEqual(second["result"], "ESCALATE")

    def test_new_evidence_does_not_extend_two_pass_budget(self):
        data = ledger()
        record_pass(data, packet([disagreement()]))
        second = record_pass(data, packet([disagreement(["new reproduction output"])]))
        self.assertEqual(second["result"], "ESCALATE")

    def test_evidence_whitespace_does_not_evade_repeat_detection(self):
        data = ledger()
        record_pass(data, packet([disagreement(["same output"])]))
        second = record_pass(data, packet([disagreement(["  same   output  "])]))
        self.assertEqual(second["result"], "ESCALATE")

    def test_malformed_string_evidence_is_rejected_before_normalization(self):
        value = disagreement()
        value["disagreement"]["evidence"] = "not-an-array"
        with self.assertRaisesRegex(ValueError, "review packet schema"):
            record_pass(ledger(), packet([value]))

    def test_p3_adjacent_repeat_never_escalates(self):
        data = ledger()
        value = disagreement(severity="P3", scope="adjacent")
        self.assertEqual(record_pass(data, packet([value]))["result"], "PASS")
        self.assertEqual(record_pass(data, packet([value]))["result"], "PASS")

    def test_out_of_scope_p1_repeat_never_escalates(self):
        data = ledger()
        value = disagreement(severity="P1", scope="out_of_scope")
        self.assertEqual(record_pass(data, packet([value]))["result"], "PASS")
        self.assertEqual(record_pass(data, packet([value]))["result"], "PASS")

    def test_second_unresolved_pass_escalates_without_disagreement(self):
        data = ledger()
        finding = {
            "finding_id": "REV-100", "severity": "P1", "scope": "in_scope",
            "status": "accepted", "resolution": "Fix remains incomplete",
        }
        self.assertEqual(record_pass(data, packet([finding]))["result"], "REQUEST_CHANGES")
        self.assertEqual(record_pass(data, packet([finding]))["result"], "ESCALATE")

    def test_third_automatic_pass_is_rejected_even_with_clean_packet(self):
        data = ledger()
        record_pass(data, packet())
        record_pass(data, packet())
        with self.assertRaisesRegex(ValueError, "review pass limit"):
            record_pass(data, packet())

    def test_historical_five_pass_ledger_remains_readable(self):
        from scripts.review_ledger import validate_ledger
        data = ledger()
        record_pass(data, packet())
        first = data["passes"][0]
        data["passes"] = [dict(first, **{"pass": number}) for number in range(1, 6)]
        validate_ledger(data)
        with self.assertRaisesRegex(ValueError, "review pass limit"):
            record_pass(data, packet())


if __name__ == "__main__":
    unittest.main()
