#!/usr/bin/env python3
"""Map unchanged code to existing review evidence; never issue a new review verdict."""
import argparse
import json
import re
import subprocess

FULL_SHA = re.compile(r"^(?:[a-f0-9]{40}|[a-f0-9]{64})$")


def equivalence(root, reviewed_sha, current_sha, reviewed_context, current_context):
    if not all(FULL_SHA.fullmatch(value) for value in (reviewed_sha, current_sha)):
        raise ValueError("full reviewed and current commit SHAs are required")
    if not reviewed_context.strip() or not current_context.strip():
        raise ValueError("observed scope/base/environment context is required")
    def git(*args):
        return subprocess.check_output(["git", "--no-replace-objects", "-C", str(root), *args], text=True).strip()
    for sha in (reviewed_sha, current_sha):
        if git("cat-file", "-t", sha) != "commit":
            raise ValueError("reviewed and current SHAs must identify commit objects")
    reasons = []
    if git("status", "--porcelain", "--untracked-files=all", "--ignore-submodules=none"):
        reasons.append("working tree is dirty")
    if git("rev-parse", "HEAD") != current_sha:
        reasons.append("current SHA is not checked-out HEAD")
    before = git("rev-parse", "--verify", reviewed_sha + "^{tree}")
    after = git("rev-parse", "--verify", current_sha + "^{tree}")
    if before != after:
        reasons.append("Git tree changed")
    if reviewed_context != current_context:
        reasons.append("scope/base/environment context changed")
    return {"reusable": not reasons, "reviewed_sha": reviewed_sha, "current_sha": current_sha,
            "reviewed_tree": before, "current_tree": after, "context": current_context,
            "reasons": reasons}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default=".")
    parser.add_argument("--reviewed-sha", required=True)
    parser.add_argument("--current-sha", required=True)
    parser.add_argument("--reviewed-context", required=True)
    parser.add_argument("--current-context", required=True)
    args = parser.parse_args()
    try:
        result = equivalence(args.repo, args.reviewed_sha, args.current_sha,
                             args.reviewed_context, args.current_context)
    except (ValueError, subprocess.CalledProcessError) as exc:
        print(json.dumps({"reusable": False, "error": str(exc)}))
        return 1
    print(json.dumps(result))
    return 0 if result["reusable"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
