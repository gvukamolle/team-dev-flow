"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const {nextWorkStage} = require("../src/adaptive-flow.cjs");

const ready = {captured: true};
const verified = {...ready, implemented: true, code_revision: "a".repeat(40), scope_revision: "chat:1",
  verification: {code_revision: "a".repeat(40), scope_revision: "chat:1", result: "PASS"}};

test("chat work needs no tracker, spec, plan, contract or independent roles by default", () => {
  assert.equal(nextWorkStage({}), "capture");
  assert.equal(nextWorkStage(ready), "implement");
  assert.equal(nextWorkStage({...ready, implemented: true}), "verify");
  assert.equal(nextWorkStage(verified), "handoff");
});

test("real uncertainty and blockers stop only the affected work", () => {
  assert.equal(nextWorkStage({...ready, blocked: true}), "blocked");
  assert.equal(nextWorkStage({...ready, blocking_questions: true}), "clarify");
  assert.equal(nextWorkStage({...ready, decision_uncertainty: true}), "research");
});

test("project requirements cannot be bypassed by completed implementation", () => {
  for (const [requirement, stage] of Object.entries({require_tracking: "tracking", require_spec: "specify",
    require_plan: "plan", require_contract: "contract"})) {
    assert.equal(nextWorkStage(verified, {[requirement]: true}), stage);
  }
  assert.equal(nextWorkStage({...verified, tracking_ready: true}, {require_tracking: true}), "handoff");
  assert.equal(nextWorkStage({...ready, migration: true}), "plan");
  assert.equal(nextWorkStage({...ready, migration: true, plan_ready: true}), "implement");
});

test("code and material scope changes invalidate evidence, a same-SHA push does not", () => {
  assert.equal(nextWorkStage({...verified, code_revision: "b".repeat(40)}), "verify");
  assert.equal(nextWorkStage({...verified, scope_revision: "chat:2"}), "verify");
  assert.equal(nextWorkStage({...verified}), "handoff");
  assert.equal(nextWorkStage({...verified, verification: {...verified.verification, result: "FAIL"}}), "verify");
  assert.equal(nextWorkStage({...ready, implemented: true, verification: {result: "PASS"}}), "verify");
});

test("independence and security review are conditional but cannot use stale or builder evidence", () => {
  assert.equal(nextWorkStage(verified, {require_independent_verification: true}), "independent-verify");
  const independentlyVerified = {...verified, verification: {...verified.verification, independent: true}};
  assert.equal(nextWorkStage(independentlyVerified, {require_independent_verification: true}), "handoff");
  assert.equal(nextWorkStage(verified, {require_review: true}), "review");
  assert.equal(nextWorkStage({...verified, security_sensitive: true}), "review");
  const reviewed = {...verified, review: {...verified.verification, independent: true}};
  assert.equal(nextWorkStage(reviewed, {require_review: true}), "handoff");
  assert.equal(nextWorkStage({...reviewed, review: {...reviewed.review, code_revision: "b".repeat(40)}}, {require_review: true}), "review");
  assert.equal(nextWorkStage({...verified, review: verified.verification}, {require_review: true}), "review");
});

test("external actions still need authority and configured policy rejects typos", () => {
  assert.equal(nextWorkStage({...verified, external_action_pending: true}), "authorize");
  assert.equal(nextWorkStage({...verified, external_action_pending: true, external_authorized: true}), "deliver");
  assert.throws(() => nextWorkStage(ready, {require_reveiw: true}), /unknown policy/);
  assert.throws(() => nextWorkStage(ready, {require_review: "false"}), /boolean/);
  assert.throws(() => nextWorkStage({...ready, security_sensitive: "false"}), /boolean/);
});

test("two actual human approvals replace the agent review, but are never assumed", () => {
  const policy = {require_review: true, human_reviews_required: 2};
  const base = {...verified, merge_request: "project/mr/12"};
  assert.equal(nextWorkStage(base, policy), "human-review");
  const human_review = {...verified.verification, kind: "human", merge_request: base.merge_request,
    eligible_approver_ids: ["person-a", "person-b"], auto_approved: false};
  assert.equal(nextWorkStage({...base, human_review}, policy), "handoff");
  for (const delta of [
    {eligible_approver_ids: ["person-a"]}, {eligible_approver_ids: ["person-a", "person-a"]},
    {auto_approved: true}, {merge_request: "project/mr/13"}, {code_revision: "b".repeat(40)},
  ]) assert.equal(nextWorkStage({...base, human_review: {...human_review, ...delta}}, policy), "human-review");
});

test("ordinary agent PASS never replaces required human approvals", () => {
  const base = {...verified, review: {...verified.verification, independent: true}};
  assert.equal(nextWorkStage(base, {human_reviews_required: 2}), "human-review");
});

test("same-tree merge reuses agent evidence mechanically with unchanged scope and context", () => {
  const previous = {...verified.verification, tree_revision: "c".repeat(40), context_revision: "base+env:1"};
  const base = {...verified, code_revision: "b".repeat(40), tree_revision: previous.tree_revision,
    context_revision: previous.context_revision, verification: previous,
    review: {...previous, independent: true}, review_rounds: 2};
  assert.equal(nextWorkStage(base, {require_review: true}), "handoff");
  assert.equal(nextWorkStage({...base, context_revision: "base+env:2"}, {require_review: true}), "verify");
  assert.equal(nextWorkStage({...base, tree_revision: "d".repeat(40)}, {require_review: true}), "verify");
  assert.equal(nextWorkStage({...base, scope_revision: "chat:2"}, {require_review: true}), "verify");
  const {context_revision, ...unbound} = base;
  assert.equal(nextWorkStage(unbound, {require_review: true}), "verify");
});

test("full review plus one delta is the automatic limit, not permission to ship defects", () => {
  assert.equal(nextWorkStage({...verified, review_rounds: 0}, {require_review: true}), "review");
  assert.equal(nextWorkStage({...verified, review_rounds: 1}, {require_review: true}), "review-delta");
  assert.equal(nextWorkStage({...verified, review_rounds: 2}, {require_review: true}), "escalate");
  assert.equal(nextWorkStage({...verified, review_rounds: 2, review: {...verified.verification, independent: true}}, {require_review: true}), "handoff");
  assert.equal(nextWorkStage({...verified, blocking_findings: true, review_rounds: 2}), "escalate");
  assert.equal(nextWorkStage({...verified, blocking_findings: true, review_rounds: 1}), "fix-findings");
});

test("material security risk needs coverage, not a separate generic audit after qualified review", () => {
  const base = {...verified, security_sensitive: true, review: {...verified.verification, independent: true}};
  assert.equal(nextWorkStage(base), "review");
  assert.equal(nextWorkStage({...base, review: {...base.review, security_reviewed: true}}), "handoff");
  const human_review = {...verified.verification, kind: "human", merge_request: "project/mr/12",
    eligible_approver_ids: ["a", "b"], auto_approved: false, security_reviewed: true};
  assert.equal(nextWorkStage({...verified, security_sensitive: true, merge_request: "project/mr/12", human_review},
    {require_review: true, human_reviews_required: 2}), "handoff");
});

test("invalid review configuration fails closed", () => {
  for (const count of [-1, 1.5, "2", null]) assert.throws(() => nextWorkStage(verified, {human_reviews_required: count}));
  assert.throws(() => nextWorkStage({...verified, review_rounds: -1}));
});


test("eligible human review follows the project count without a corporate minimum", () => {
  const policy = {require_review: true, human_reviews_required: 1};
  const human_review = {...verified.verification, kind: "human", merge_request: "project/mr/12",
    eligible_approver_ids: ["person-a"], auto_approved: false, security_reviewed: true};
  const base = {...verified, merge_request: "project/mr/12", human_review};
  assert.equal(nextWorkStage(base, policy), "handoff");
  assert.equal(nextWorkStage({...base, security_sensitive: true}, policy), "handoff");
  assert.equal(nextWorkStage({...base, review: {...verified.verification, independent: true}}, policy), "handoff");
  assert.equal(nextWorkStage({...base, human_review: {...human_review, eligible_approver_ids: ["person-a", "person-b"]}}, policy), "handoff");
});
