"use strict";

const POLICY_FLAGS = new Set(["require_tracking", "require_spec", "require_plan", "require_contract",
  "require_independent_verification", "require_review"]);
const STATE_FLAGS = new Set(["captured", "blocked", "blocking_questions", "decision_uncertainty",
  "tracking_ready", "spec_ready", "plan_ready", "contract_ready", "migration", "security_sensitive",
  "implemented", "external_action_pending", "external_authorized", "blocking_findings"]);

function object(value, name) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${name} must be an object`);
}

function validate(state, policy) {
  object(state, "state");
  object(policy, "policy");
  for (const [key, value] of Object.entries(policy)) {
    if (key === "human_reviews_required") {
      if (!Number.isInteger(value) || value < 0 || value > 100) throw new Error(`${key} must be an integer from 0 to 100`);
      continue;
    }
    if (!POLICY_FLAGS.has(key)) throw new Error(`unknown policy: ${key}`);
    if (typeof value !== "boolean") throw new Error(`${key} must be boolean`);
  }
  for (const [key, value] of Object.entries(state)) {
    if (STATE_FLAGS.has(key)) {
      if (typeof value !== "boolean") throw new Error(`${key} must be boolean`);
    } else if (key === "review_rounds") {
      if (!Number.isInteger(value) || value < 0) throw new Error("review_rounds must be a nonnegative integer");
    } else if (["code_revision", "scope_revision", "tree_revision", "context_revision", "merge_request"].includes(key)) {
      if (typeof value !== "string" || !value.trim()) throw new Error(`${key} must be a nonempty string`);
    } else if (["verification", "review", "human_review"].includes(key)) {
      object(value, key);
    } else throw new Error(`unknown state: ${key}`);
  }
}

const FULL_SHA = /^(?:[a-f0-9]{40}|[a-f0-9]{64})$/;

function currentEvidence(evidence, state, independent = false, allowTreeReuse = true) {
  const sameContext = !state.context_revision || evidence?.context_revision === state.context_revision;
  const sameCode = evidence?.code_revision === state.code_revision;
  const sameTree = allowTreeReuse && FULL_SHA.test(state.tree_revision || "")
    && evidence?.tree_revision === state.tree_revision && Boolean(state.context_revision) && sameContext;
  return Boolean(state.code_revision && state.scope_revision && evidence?.result === "PASS"
    && (sameCode || sameTree) && sameContext && evidence.scope_revision === state.scope_revision
    && (!independent || evidence.independent === true));
}

function humanReviewCurrent(state, count) {
  const evidence = state.human_review;
  const ids = evidence?.eligible_approver_ids;
  return Boolean(count > 0 && evidence?.kind === "human" && evidence.auto_approved === false
    && state.merge_request && evidence.merge_request === state.merge_request
    && FULL_SHA.test(state.code_revision || "") && currentEvidence(evidence, state, false, false)
    && Array.isArray(ids) && ids.every(id => typeof id === "string" && id.trim() && id === id.trim())
    && new Set(ids).size >= count);
}

function reviewStage(state, policy) {
  const rounds = state.review_rounds || 0;
  if (state.blocking_findings) return rounds >= 2 ? "escalate" : "fix-findings";
  const humanCount = policy.human_reviews_required || 0;
  const humanPass = humanReviewCurrent(state, humanCount);
  // Planned human reviews are a real pending gate, never an automatic PASS.
  if (humanCount && !humanPass) return "human-review";
  const coveringHumanReview = humanReviewCurrent(state, Math.max(1, humanCount));
  const agentPass = currentEvidence(state.review, state, true);
  const generalPass = agentPass || coveringHumanReview;
  const securityPass = (agentPass && state.review.security_reviewed === true)
    || (coveringHumanReview && state.human_review.security_reviewed === true);
  if ((policy.require_review && !generalPass) || (state.security_sensitive && !securityPass)) {
    if (rounds >= 2) return "escalate";
    return rounds === 1 ? "review-delta" : "review";
  }
  return null;
}

// A routing helper, never an authorization or proof issuer. The host supplies
// policy from applicable repository rules and evidence from actual checks.
function nextWorkStage(state = {}, policy = {}) {
  validate(state, policy);
  if (!state.captured) return "capture";
  if (state.blocked) return "blocked";
  if (state.blocking_questions) return "clarify";
  if (state.decision_uncertainty) return "research";
  if (policy.require_tracking && !state.tracking_ready) return "tracking";
  if (policy.require_spec && !state.spec_ready) return "specify";
  if ((policy.require_plan || state.migration) && !state.plan_ready) return "plan";
  if (policy.require_contract && !state.contract_ready) return "contract";
  if (!state.implemented) return "implement";
  if (!currentEvidence(state.verification, state)) return "verify";
  if (policy.require_independent_verification && !currentEvidence(state.verification, state, true)) return "independent-verify";
  const pendingReview = reviewStage(state, policy);
  if (pendingReview) return pendingReview;
  if (state.external_action_pending) return state.external_authorized ? "deliver" : "authorize";
  return "handoff";
}

module.exports = {nextWorkStage};
