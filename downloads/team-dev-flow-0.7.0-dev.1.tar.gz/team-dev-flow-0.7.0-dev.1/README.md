# Team Dev Flow

**Give the work a shared direction.**

An open-source workflow plugin for coding agents. Start from a chat request,
keep the change within agreed scope, run the checks that matter, and hand off
with evidence. Works with Codex and Kilo Code.

```text
Understand → Implement → Verify → Report
```

A quick fix stays quick. Add research, a specification, task decomposition or
independent review when you ask for it or your project requires it. Structured
SDD and versioned contracts remain available without becoming mandatory intake.

## Try one task

After installation, ask:

> Use Team Dev Flow. Fix this issue, preserve unrelated work, and show how you checked it.

For larger work:

> Plan this feature before implementation. Clarify permissions and split the work into bounded tasks.

For review:

> Review this change against the agreed behavior. Trace consequential findings and check the fixes in one delta pass.

## Install in Codex

These commands install the **published canary**, which may be older than this
`0.7.0-dev.1` refresh candidate until the marketplace is promoted:

```bash
codex plugin marketplace add https://github.com/gvukamolle/team-dev-flow-marketplace.git --json
codex plugin add team-dev-flow@team-flow --json
```

Restart Codex and open a new task. To pin a reviewed marketplace snapshot, add
`--ref` followed by its full verified commit SHA to the first command.

## Install the candidate in Kilo Code

From an extracted candidate package or reviewed checkout, replace `/path/to/project`:

```bash
python3 scripts/host_package.py preview --host kilo --workspace /path/to/project
python3 scripts/host_package.py install --host kilo --workspace /path/to/project
python3 scripts/host_package.py check --host kilo --workspace /path/to/project
```

Run `/reload` and select the `team-dev-flow` agent. Installation refuses managed-file
drift, unowned collisions and symlinks. Preview before applying a project-local install.

## Load the candidate in Claude Code

Download and extract the candidate package, then launch Claude Code from your project:

```bash
claude --plugin-dir /absolute/path/to/team-dev-flow-0.7.0-dev.1
```

The `.claude-plugin/plugin.json` manifest exposes the shared skills for that session.
Its structure is checked with `claude plugin validate . --strict`; this is manifest
validation, not an independent real-task pilot. Ask Claude to use Team Dev Flow.
See the [official local plugin instructions](https://code.claude.com/docs/en/plugins).

## Optional tracked work

- `generic`: local Git and optional planning without a remote tracker.
- `obsidian-local`: a selected Local Markdown/Obsidian TaskStore.
- `kilo-github`: bounded GitHub Issue reads and Issue/PR command previews.

```bash
python3 scripts/local_task_store.py init --vault "/path/to/vault" --folder "Projects/Team Dev Flow"
python3 scripts/local_task_store.py upsert --root "/path/to/vault/Projects/Team Dev Flow" --project FLOW --kind project --id FLOW --title "Team Dev Flow"
```

The local adapter preserves user content and unknown properties, records history,
and refuses unsafe paths or conflicting writes. It does not edit `.obsidian`.
The GitHub adapter exposes previews, not an apply command. Other provider contracts
are extension points, not claims of implemented integrations.

## Review and authority

Required agent review has one full pass plus one delta. Reuse eligible human review
under your project's rules. Evidence names the code actually checked; a same-SHA
push does not invalidate it. Identical clean trees need verified context equivalence.
A review PASS never authorizes push, merge, publication or deployment.

Universal includes no organization-specific Jira server, project-routing skills,
internal settings, fixed branch topology or corporate approval count.

## Development

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
PATH="$PWD/.venv/bin:$PATH" npm test
.venv/bin/python scripts/validate_repository.py
.venv/bin/python scripts/package_release.py
.venv/bin/python scripts/verify_package.py
```

The repository also contains `site/` (standalone landing page) and `marketing/`
(launch copy and generated campaign assets). They stay outside the plugin archive.
Serve the landing locally with `python3 -m http.server 8787 --directory site`.

Apache-2.0. Bring your own agent and its required account or runtime.
